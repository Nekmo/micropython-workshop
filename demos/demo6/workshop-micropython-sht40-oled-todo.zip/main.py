from machine import Pin, I2C
from time import sleep
from ssd1306 import SSD1306_I2C
from sht4x import SHT4X


# TODO: asigna a cada pin su número GPIO.
#   https://docs.micropython.org/en/latest/library/machine.Pin.html
scl = Pin(...)
sda = Pin(...)
# TODO: crea una instancia de I2C()
#   - Argumento 1 (requerido): identificador que ponemos para diferenciar el I2C. Pondremos 0.
#   - Parámetro scl=<valor>: instancia pin correspondiente al GPIO SCL.
#   - Parámetro sda=<valor>: instancia pin correspondiente al GPIO SDA.
#   https://docs.micropython.org/en/latest/library/machine.I2C.html
i2c = ...
# Mostrar los dispositivos I2C que tenemos conectados al I2C:
print(i2c.scan())

# TODO: implementar la instancia SSD1306_I2C()
#   - Argumento 1 (requerido): ancho de la pantalla en pixels (int)
#   - Argumento 2 (requerido): alto de la pantalla en pixels (int)
#   - Argumento 3 (requerido): instancia de I2C()
#   - Argumento 4 (opcional): dirección I2C. Ejemplo: 0x00
#   https://docs.micropython.org/en/latest/esp8266/tutorial/ssd1306.html
oled = ...
# TODO: implementar la instancia SHT4X()
#   - Argumento 1 (requerido): instancia de I2C()
#   - Argumento 2 (opcional): dirección I2C. Ejemplo: 0x00
#   https://github.com/jposada202020/MicroPython_SHT4X/blob/master/micropython_sht4x/sht4x.py
sensor = ...


while True:
    # TODO: accede a la propiedad measurements de la instancia SHT4X(), que nos devuelve 
    #   la temperatura y humedad actual, respectivamente
    #   https://github.com/jposada202020/MicroPython_SHT4X/blob/master/micropython_sht4x/sht4x.py#L146
    temperature, humidity = ...
    # TODO: llenar toda la pantalla de un solo color para resetearla.
    #   Usa el método fill de la instancia SSD1306_I2C() usando como argumento un cero (0).
    #   https://docs.micropython.org/en/latest/library/framebuf.html#framebuf.FrameBuffer.fill
    ...
    temperature_text = "Temp: {:.1f} C".format(temperature)
    humidity_text = "Hum:  {:.1f} %".format(humidity)
    # TODO: usa el método text() de la instancia SSD1306_I2C() dos veces, uno por cada texto,
    #   para escribir los textos en pantalla.
    #   - Argumento 1 (requerido): texto a escribir.
    #   - Argumento 2 (requerido): a partir de qué pixel de ancho escribir. Usaremos cero (0).
    #   - Argumento 3 (requerido): a partir de qué pixel de altura escribir. Primero 0 y luego 30.
    #   https://docs.micropython.org/en/latest/library/framebuf.html#framebuf.FrameBuffer.text
    ...
    ...
    # TODO: para mostrar todo lo dibujado, usar el método show() de la instancia SSD1306_I2C()
    #   https://docs.micropython.org/en/latest/esp8266/tutorial/ssd1306.html
    ...
    sleep(2)
