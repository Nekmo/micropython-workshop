from machine import Pin, I2C
from time import sleep
from ssd1306 import SSD1306_I2C
from sht4x import SHT4X


scl = Pin(1)
sda = Pin(2)
i2c = I2C(0, scl=scl, sda=sda)
print(i2c.scan())

oled = SSD1306_I2C(128, 64, i2c, 0x3C)
sensor = SHT4X(i2c, 0x44)


while True:
    temperature, humidity = sensor.measurements
    oled.fill(0)
    temperature_text = "Temp: {:.1f} C".format(temperature)
    humidity_text = "Hum:  {:.1f} %".format(humidity)
    oled.text(temperature_text, 0, 10)
    oled.text(humidity_text, 0, 30)
    oled.show()
    sleep(2)
