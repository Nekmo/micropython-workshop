from machine import Pin, UART
from time import sleep

# TODO: implementa la instancia Pin()
#   - Argumento 1 (requerido): número de GPIO
#   - Argumento 2 (opcional, por defecto Pin.OUT): usa modo entrada. Pin.IN
#   - Argumento 3 (opcional, por defecto None): usa la resistencia interna Pin.PULL_UP
#   Define estos argumentos opcionales para cambiar el valor por defecto. La resistencia
#   interna Pull-up nos evita colocar una resistencia. El valor por defecto cuando no 
#   pulsamos será 1 (HIGH).
#   https://docs.micropython.org/en/latest/library/machine.Pin.html
button = Pin(..., ..., ...)


while True:
    # TODO: utiliza el método value() de la instancia Pin() para obtener su valor actual.
    #   recuerda negar el valor, ya que el valor no pulsado será 1 (HIGH)
    #   https://docs.micropython.org/en/latest/library/machine.Pin.html#machine.Pin.value
    state = ...
    print(int(state))
    sleep(0.1)