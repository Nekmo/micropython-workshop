from machine import Pin
from time import sleep

# TODO: instanciar Pin()
#   - Argumento 1 (requerido): número de GPIO
#   - Argumento 2 (opcional): por defecto Pin.OUT (salida)
#   https://docs.micropython.org/en/latest/library/machine.Pin.html
led = ...

while True:
    # TODO: encender el led usando método on()
    #   https://docs.micropython.org/en/latest/library/machine.Pin.html#machine.Pin.on
    ...
    sleep(0.5)
    # TODO: encender el led usando método off()
    #   https://docs.micropython.org/en/latest/library/machine.Pin.html#machine.Pin.off
    ...
    sleep(0.5)