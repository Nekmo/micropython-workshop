from machine import Pin, PWM
from time import sleep
import urandom


# TODO: asigna a cada pin un número GPIO, correspondiente a un color 
#   (r = red, g = green, b = blue). Usaremos cable amarillo para el led rojo.
#   https://docs.micropython.org/en/latest/library/machine.Pin.html
r = PWM(Pin(...), freq=1000)
g = PWM(Pin(...), freq=1000)
b = PWM(Pin(...), freq=1000)


def set_color(red, green, blue):
    # TODO: ejecuta el método duty() por cada color, usando como argumento su valor
    #   https://docs.micropython.org/en/latest/esp8266/quickref.html#pwm-pulse-width-modulation
    ...


while True:
    red = urandom.getrandbits(10)
    green = urandom.getrandbits(10)
    blue = urandom.getrandbits(10)
    set_color(red, green, blue)
    sleep(1)
