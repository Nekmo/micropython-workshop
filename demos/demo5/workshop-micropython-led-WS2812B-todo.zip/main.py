from machine import Pin
from apa106 import APA106
from time import sleep

# TODO: definir el número de leds que tenemos
NUM_LEDS = ...

# TODO: implementa la instancia Pin()
#   - Argumento 1 (requerido): número de GPIO
#   https://docs.micropython.org/en/latest/library/machine.Pin.html
pin = Pin(...)
# TODO: implementa la instancia APA106()
#   - Argumento 1 (requerido): instancia Pin() a utilizar
#   - Argumento 2 (requerido): número de leds
#   https://docs.micropython.org/en/latest/esp32/quickref.html#neopixel-and-apa106-driver
leds = ...
colors = [
    (255, 0, 0),
    (0, 255, 0),
    (0, 0, 255),
]
offset = 0


while True:
    for num_led in range(NUM_LEDS):
        next_color = colors[(num_led + offset) % NUM_LEDS]
        # TODO: la instancia leds de APA106() se comporta como una lista de leds. Cada led
        #   es accesible usando leds[<pos del led>], y como valor podemos ponerle un color.
        #   Para el número de led que estamos en el bucle, poner el siguiente color.
        #   https://docs.micropython.org/en/latest/esp32/quickref.html#neopixel-and-apa106-driver
        leds[...] = ...
    # TODO: para aplicar los colores, debemos ejecutar write() de la instancia APA106().
    #   https://docs.micropython.org/en/latest/esp32/quickref.html#neopixel-and-apa106-driver
    ...
    offset = (offset + 1) % NUM_LEDS
    sleep(0.5)
