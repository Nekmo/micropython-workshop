from machine import Pin
from apa106 import APA106
from time import sleep

NUM_LEDS = 3

pin = Pin(1)
leds = APA106(pin, NUM_LEDS)
colors = [
    (255, 0, 0),
    (0, 255, 0),
    (0, 0, 255),
]
offset = 0


while True:
    for num_led in range(NUM_LEDS):
        next_color = colors[(num_led + offset) % NUM_LEDS]
        leds[num_led] = next_color
    leds.write()
    offset = (offset + 1) % NUM_LEDS
    sleep(0.5)
