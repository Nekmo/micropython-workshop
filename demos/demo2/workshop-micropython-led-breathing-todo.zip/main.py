from machine import Pin, PWM
from time import sleep

# TODO: pon el número de GPIO utilizado
led = Pin(...)
# TODO: crea una instancia de PWM
#   - Argumento 1 (requerido): instancia de Pin() que se usará
#   https://docs.micropython.org/en/latest/library/machine.PWM.html#constructors
pwm = ...


while True:
    for i in range(0, 1024, 10):
        # TODO: ejecuta el método duty() de la instancia pwm con un valor 0-1023
        #   https://docs.micropython.org/en/latest/esp8266/quickref.html#pwm-pulse-width-modulation
        ...
        sleep(0.01)
    for i in range(1023, -1, -10):
        # TODO: ejecuta el método duty() de la instancia pwm con un valor 0-1023
        #   https://docs.micropython.org/en/latest/esp8266/quickref.html#pwm-pulse-width-modulation
        ...
        sleep(0.01)